How to run:

npm install
npm start
